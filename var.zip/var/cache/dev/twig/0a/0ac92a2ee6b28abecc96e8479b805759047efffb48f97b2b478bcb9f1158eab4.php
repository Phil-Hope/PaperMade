<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* books/show.html.twig */
class __TwigTemplate_37c6412ccb32037a1da00f7f61d728c4f7adc33eb6033e30f415642fc5f5c241 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "books/show.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "books/show.html.twig"));

        // line 1
        $this->loadTemplate("include/header.html.twig", "books/show.html.twig", 1)->display($context);
        // line 2
        echo "<div class=\"row\">
    <div class=\"col-2\">
        ";
        // line 4
        $this->loadTemplate("include/adminpanel.html.twig", "books/show.html.twig", 4)->display($context);
        // line 5
        echo "    </div>

    <div class=\"col-8\">
    <table class=\"table\">
        <h1>Books</h1>
        <tbody>
        <tr>
            <th>BookTitle:</th>
            <td>";
        // line 13
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["book"]) || array_key_exists("book", $context) ? $context["book"] : (function () { throw new RuntimeError('Variable "book" does not exist.', 13, $this->source); })()), "BookTitle", [], "any", false, false, false, 13), "html", null, true);
        echo "</td>
        </tr>
                <td><img class=\"img-thumbnail\" style=\"max-height: 15vw; width:auto;\" src=\"";
        // line 15
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["book"]) || array_key_exists("book", $context) ? $context["book"] : (function () { throw new RuntimeError('Variable "book" does not exist.', 15, $this->source); })()), "coverImagePath", [], "any", false, false, false, 15), "html", null, true);
        echo "\"></td>
            <tr>
                <th>Original Title:</th>
                <td>";
        // line 18
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["book"]) || array_key_exists("book", $context) ? $context["book"] : (function () { throw new RuntimeError('Variable "book" does not exist.', 18, $this->source); })()), "OriginalTitle", [], "any", false, false, false, 18), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Year of Publication:</th>
                <td>";
        // line 22
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["book"]) || array_key_exists("book", $context) ? $context["book"] : (function () { throw new RuntimeError('Variable "book" does not exist.', 22, $this->source); })()), "YearofPublication", [], "any", false, false, false, 22), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Genre:</th>
                <td>";
        // line 26
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["book"]) || array_key_exists("book", $context) ? $context["book"] : (function () { throw new RuntimeError('Variable "book" does not exist.', 26, $this->source); })()), "Genre", [], "any", false, false, false, 26), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Millions Sold:</th>
                <td>";
        // line 30
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["book"]) || array_key_exists("book", $context) ? $context["book"] : (function () { throw new RuntimeError('Variable "book" does not exist.', 30, $this->source); })()), "MillionsSold", [], "any", false, false, false, 30), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Language Written:</th>
                <td>";
        // line 34
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["book"]) || array_key_exists("book", $context) ? $context["book"] : (function () { throw new RuntimeError('Variable "book" does not exist.', 34, $this->source); })()), "LanguageWritten", [], "any", false, false, false, 34), "html", null, true);
        echo "</td>
            </tr>
        ";
        // line 36
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["authors"]) || array_key_exists("authors", $context) ? $context["authors"] : (function () { throw new RuntimeError('Variable "authors" does not exist.', 36, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["author"]) {
            // line 37
            echo "
            ";
            // line 38
            if (0 === twig_compare(twig_get_attribute($this->env, $this->source, (isset($context["book"]) || array_key_exists("book", $context) ? $context["book"] : (function () { throw new RuntimeError('Variable "book" does not exist.', 38, $this->source); })()), "Author", [], "any", false, false, false, 38), twig_get_attribute($this->env, $this->source, $context["author"], "id", [], "any", false, false, false, 38))) {
                // line 39
                echo "            <tr>
                <th>Author:</th>
                <td><a href=\"";
                // line 41
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("author_show", ["id" => twig_get_attribute($this->env, $this->source, $context["author"], "id", [], "any", false, false, false, 41)]), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["author"], "Name", [], "any", false, false, false, 41), "html", null, true);
                echo " ";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["author"], "Surname", [], "any", false, false, false, 41), "html", null, true);
                echo "</a></td>
            </tr>";
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['author'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 43
        echo "            <tr>
                <th>Plot:</th>
                <td>";
        // line 45
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["book"]) || array_key_exists("book", $context) ? $context["book"] : (function () { throw new RuntimeError('Variable "book" does not exist.', 45, $this->source); })()), "Plot", [], "any", false, false, false, 45), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>PlotSource</th>
                <td><a href=\"";
        // line 49
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["book"]) || array_key_exists("book", $context) ? $context["book"] : (function () { throw new RuntimeError('Variable "book" does not exist.', 49, $this->source); })()), "PlotSource", [], "any", false, false, false, 49), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["book"]) || array_key_exists("book", $context) ? $context["book"] : (function () { throw new RuntimeError('Variable "book" does not exist.', 49, $this->source); })()), "PlotSource", [], "any", false, false, false, 49), "html", null, true);
        echo "</a></td>
            </tr>
        </tbody>
    </table>
    <a class=\"btn btn-warning\" style=\"height: 1.5vw; width: 4vw;\"   href=\"";
        // line 53
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("books_edit", ["id" => twig_get_attribute($this->env, $this->source, (isset($context["book"]) || array_key_exists("book", $context) ? $context["book"] : (function () { throw new RuntimeError('Variable "book" does not exist.', 53, $this->source); })()), "id", [], "any", false, false, false, 53)]), "html", null, true);
        echo "\"><strong>EDIT</strong></a>
    ";
        // line 54
        echo twig_include($this->env, $context, "books/_delete_form.html.twig");
        echo "
</div>
</div>
</div>
";
        // line 58
        $this->loadTemplate("include/footer.html.twig", "books/show.html.twig", 58)->display($context);
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "books/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  162 => 58,  155 => 54,  151 => 53,  142 => 49,  135 => 45,  131 => 43,  118 => 41,  114 => 39,  112 => 38,  109 => 37,  105 => 36,  100 => 34,  93 => 30,  86 => 26,  79 => 22,  72 => 18,  66 => 15,  61 => 13,  51 => 5,  49 => 4,  45 => 2,  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% include 'include/header.html.twig' %}
<div class=\"row\">
    <div class=\"col-2\">
        {% include 'include/adminpanel.html.twig' %}
    </div>

    <div class=\"col-8\">
    <table class=\"table\">
        <h1>Books</h1>
        <tbody>
        <tr>
            <th>BookTitle:</th>
            <td>{{ book.BookTitle }}</td>
        </tr>
                <td><img class=\"img-thumbnail\" style=\"max-height: 15vw; width:auto;\" src=\"{{ book.coverImagePath }}\"></td>
            <tr>
                <th>Original Title:</th>
                <td>{{ book.OriginalTitle }}</td>
            </tr>
            <tr>
                <th>Year of Publication:</th>
                <td>{{ book.YearofPublication }}</td>
            </tr>
            <tr>
                <th>Genre:</th>
                <td>{{ book.Genre }}</td>
            </tr>
            <tr>
                <th>Millions Sold:</th>
                <td>{{ book.MillionsSold }}</td>
            </tr>
            <tr>
                <th>Language Written:</th>
                <td>{{ book.LanguageWritten }}</td>
            </tr>
        {% for author in authors %}

            {% if book.Author == author.id %}
            <tr>
                <th>Author:</th>
                <td><a href=\"{{ path('author_show', {'id': author.id}) }}\">{{ author.Name }} {{ author.Surname}}</a></td>
            </tr>{% endif %}{% endfor %}
            <tr>
                <th>Plot:</th>
                <td>{{ book.Plot }}</td>
            </tr>
            <tr>
                <th>PlotSource</th>
                <td><a href=\"{{ book.PlotSource }}\">{{ book.PlotSource }}</a></td>
            </tr>
        </tbody>
    </table>
    <a class=\"btn btn-warning\" style=\"height: 1.5vw; width: 4vw;\"   href=\"{{ path('books_edit', {'id': book.id}) }}\"><strong>EDIT</strong></a>
    {{ include('books/_delete_form.html.twig') }}
</div>
</div>
</div>
{% include 'include/footer.html.twig' %}
", "books/show.html.twig", "/usr/share/nginx/html/sybook/templates/books/show.html.twig");
    }
}
