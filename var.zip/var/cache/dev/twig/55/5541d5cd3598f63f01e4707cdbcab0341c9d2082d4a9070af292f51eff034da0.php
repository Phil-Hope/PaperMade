<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* author/show.html.twig */
class __TwigTemplate_5fb00bbc294f670ce454db741471b41ea8975d17355d426d04478580b4b4d910 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "author/show.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "author/show.html.twig"));

        // line 1
        $this->loadTemplate("include/header.html.twig", "author/show.html.twig", 1)->display($context);
        // line 2
        echo "<h1>Add new Books</h1>
<div class=\"row\">
    <div class=\"col-2\">
        ";
        // line 5
        $this->loadTemplate("include/adminpanel.html.twig", "author/show.html.twig", 5)->display($context);
        // line 6
        echo "    </div>
    <h1>Author</h1>
        <div class=\"col-8\">
    <table class=\"table\">
        <tbody>
            <tr>
                <th>Id</th>
                <td>";
        // line 13
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["author"]) || array_key_exists("author", $context) ? $context["author"] : (function () { throw new RuntimeError('Variable "author" does not exist.', 13, $this->source); })()), "id", [], "any", false, false, false, 13), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Name</th>
                <td>";
        // line 17
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["author"]) || array_key_exists("author", $context) ? $context["author"] : (function () { throw new RuntimeError('Variable "author" does not exist.', 17, $this->source); })()), "Name", [], "any", false, false, false, 17), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Surname</th>
                <td>";
        // line 21
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["author"]) || array_key_exists("author", $context) ? $context["author"] : (function () { throw new RuntimeError('Variable "author" does not exist.', 21, $this->source); })()), "Surname", [], "any", false, false, false, 21), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Nationality</th>
                <td>";
        // line 25
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["author"]) || array_key_exists("author", $context) ? $context["author"] : (function () { throw new RuntimeError('Variable "author" does not exist.', 25, $this->source); })()), "Nationality", [], "any", false, false, false, 25), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>BirthYear</th>
                <td>";
        // line 29
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["author"]) || array_key_exists("author", $context) ? $context["author"] : (function () { throw new RuntimeError('Variable "author" does not exist.', 29, $this->source); })()), "BirthYear", [], "any", false, false, false, 29), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>DeathYear</th>
                <td>";
        // line 33
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["author"]) || array_key_exists("author", $context) ? $context["author"] : (function () { throw new RuntimeError('Variable "author" does not exist.', 33, $this->source); })()), "DeathYear", [], "any", false, false, false, 33), "html", null, true);
        echo "</td>
            </tr>";
        // line 34
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["books"]) || array_key_exists("books", $context) ? $context["books"] : (function () { throw new RuntimeError('Variable "books" does not exist.', 34, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["book"]) {
            // line 35
            echo "            ";
            if (0 === twig_compare(twig_get_attribute($this->env, $this->source, $context["book"], "Author", [], "any", false, false, false, 35), twig_get_attribute($this->env, $this->source, (isset($context["author"]) || array_key_exists("author", $context) ? $context["author"] : (function () { throw new RuntimeError('Variable "author" does not exist.', 35, $this->source); })()), "id", [], "any", false, false, false, 35))) {
                // line 36
                echo "            <tr>
                <th>Books Written</th>
                <td><a href=\"";
                // line 38
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("books_show", ["id" => twig_get_attribute($this->env, $this->source, $context["book"], "id", [], "any", false, false, false, 38)]), "html", null, true);
                echo "\"><img class=\"img-thumbnail\" style=\"max-height: 10vw; width: auto;\" src=\"";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["book"], "coverImagePath", [], "any", false, false, false, 38), "html", null, true);
                echo "\"></a></td>
            ";
            }
            // line 40
            echo "            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['book'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 41
        echo "            </tr>
        </tbody>
    </table>
            <a class=\"btn btn-warning\" style=\"height: 1.5vw; width: 4vw;\"  href=\"";
        // line 44
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("author_edit", ["id" => twig_get_attribute($this->env, $this->source, (isset($context["author"]) || array_key_exists("author", $context) ? $context["author"] : (function () { throw new RuntimeError('Variable "author" does not exist.', 44, $this->source); })()), "id", [], "any", false, false, false, 44)]), "html", null, true);
        echo "\"><strong>EDIT</strong></a>
        </div>
    </div>
    ";
        // line 47
        echo twig_include($this->env, $context, "author/_delete_form.html.twig");
        echo "
        ";
        // line 48
        $this->loadTemplate("include/footer.html.twig", "author/show.html.twig", 48)->display($context);
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "author/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  139 => 48,  135 => 47,  129 => 44,  124 => 41,  118 => 40,  111 => 38,  107 => 36,  104 => 35,  100 => 34,  96 => 33,  89 => 29,  82 => 25,  75 => 21,  68 => 17,  61 => 13,  52 => 6,  50 => 5,  45 => 2,  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% include 'include/header.html.twig' %}
<h1>Add new Books</h1>
<div class=\"row\">
    <div class=\"col-2\">
        {% include 'include/adminpanel.html.twig' %}
    </div>
    <h1>Author</h1>
        <div class=\"col-8\">
    <table class=\"table\">
        <tbody>
            <tr>
                <th>Id</th>
                <td>{{ author.id }}</td>
            </tr>
            <tr>
                <th>Name</th>
                <td>{{ author.Name }}</td>
            </tr>
            <tr>
                <th>Surname</th>
                <td>{{ author.Surname }}</td>
            </tr>
            <tr>
                <th>Nationality</th>
                <td>{{ author.Nationality }}</td>
            </tr>
            <tr>
                <th>BirthYear</th>
                <td>{{ author.BirthYear }}</td>
            </tr>
            <tr>
                <th>DeathYear</th>
                <td>{{ author.DeathYear }}</td>
            </tr>{% for book in books %}
            {% if book.Author == author.id %}
            <tr>
                <th>Books Written</th>
                <td><a href=\"{{ path('books_show', {'id': book.id}) }}\"><img class=\"img-thumbnail\" style=\"max-height: 10vw; width: auto;\" src=\"{{ book.coverImagePath }}\"></a></td>
            {% endif %}
            {% endfor %}
            </tr>
        </tbody>
    </table>
            <a class=\"btn btn-warning\" style=\"height: 1.5vw; width: 4vw;\"  href=\"{{ path('author_edit', {'id': author.id}) }}\"><strong>EDIT</strong></a>
        </div>
    </div>
    {{ include('author/_delete_form.html.twig') }}
        {% include 'include/footer.html.twig' %}
", "author/show.html.twig", "/usr/share/nginx/html/sybook/templates/author/show.html.twig");
    }
}
