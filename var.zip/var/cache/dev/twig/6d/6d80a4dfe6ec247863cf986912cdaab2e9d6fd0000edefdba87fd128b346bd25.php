<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* author/new.html.twig */
class __TwigTemplate_3948bb89fa408b1b70ad7f9a56d6155d753920ac0ef50918eef8b8324a01f0ee extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "author/new.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "author/new.html.twig"));

        // line 1
        $this->loadTemplate("include/header.html.twig", "author/new.html.twig", 1)->display($context);
        // line 2
        echo "
    <div class=\"row\">
        <div class=\"col-1\">
    <h1>Create new Author</h1>
            ";
        // line 6
        $this->loadTemplate("include/adminpanel.html.twig", "author/new.html.twig", 6)->display($context);
        // line 7
        echo "        </div>
        <div class=\"container\">
            <div class=\"col-8\">
    ";
        // line 10
        echo twig_include($this->env, $context, "author/_form.html.twig");
        echo "
            </div>
        </div>
    </div>
<div class=\"row\">
    <div class=\"container\">
        <table class=\"table\">
            <h1>Authors In Database</h1>
            <thead>
            <tr>
                <th>Full Name</th>
                <th>Nationality</th>
                <th>BirthYear</th>
                <th>DeathYear</th>
            </tr>
            </thead>
            <tbody>
            ";
        // line 27
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["authors"]) || array_key_exists("authors", $context) ? $context["authors"] : (function () { throw new RuntimeError('Variable "authors" does not exist.', 27, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["author"]) {
            // line 28
            echo "                <tr>
                    <td>";
            // line 29
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["author"], "Name", [], "any", false, false, false, 29), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["author"], "Surname", [], "any", false, false, false, 29), "html", null, true);
            echo "</td>
                    <td>";
            // line 30
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["author"], "Nationality", [], "any", false, false, false, 30), "html", null, true);
            echo "</td>
                    <td>";
            // line 31
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["author"], "BirthYear", [], "any", false, false, false, 31), "html", null, true);
            echo "</td>
                    <td>";
            // line 32
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["author"], "DeathYear", [], "any", false, false, false, 32), "html", null, true);
            echo "</td>
                </tr>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['author'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 35
        echo "            </tbody>
        </table>
    </div>
</div>
";
        // line 39
        $this->loadTemplate("include/footer.html.twig", "author/new.html.twig", 39)->display($context);
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "author/new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  114 => 39,  108 => 35,  99 => 32,  95 => 31,  91 => 30,  85 => 29,  82 => 28,  78 => 27,  58 => 10,  53 => 7,  51 => 6,  45 => 2,  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% include 'include/header.html.twig' %}

    <div class=\"row\">
        <div class=\"col-1\">
    <h1>Create new Author</h1>
            {% include 'include/adminpanel.html.twig' %}
        </div>
        <div class=\"container\">
            <div class=\"col-8\">
    {{ include('author/_form.html.twig') }}
            </div>
        </div>
    </div>
<div class=\"row\">
    <div class=\"container\">
        <table class=\"table\">
            <h1>Authors In Database</h1>
            <thead>
            <tr>
                <th>Full Name</th>
                <th>Nationality</th>
                <th>BirthYear</th>
                <th>DeathYear</th>
            </tr>
            </thead>
            <tbody>
            {% for author in authors %}
                <tr>
                    <td>{{ author.Name }} {{ author.Surname }}</td>
                    <td>{{ author.Nationality }}</td>
                    <td>{{ author.BirthYear }}</td>
                    <td>{{ author.DeathYear }}</td>
                </tr>
            {% endfor %}
            </tbody>
        </table>
    </div>
</div>
{% include 'include/footer.html.twig' %}
", "author/new.html.twig", "/usr/share/nginx/html/sybook/templates/author/new.html.twig");
    }
}
