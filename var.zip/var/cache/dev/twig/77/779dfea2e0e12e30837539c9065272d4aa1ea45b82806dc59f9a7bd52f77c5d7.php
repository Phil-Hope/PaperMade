<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* add_user/index.html.twig */
class __TwigTemplate_0731ce4062302d0cbb272c0f8540136731032a12c0fb4ecce4bde5d6341926fc extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "add_user/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "add_user/index.html.twig"));

        // line 1
        $this->loadTemplate("include/header.html.twig", "add_user/index.html.twig", 1)->display($context);
        // line 2
        echo "
<div class=\"row\">
    <div class=\"col-1\">
        ";
        // line 5
        $this->loadTemplate("include/adminpanel.html.twig", "add_user/index.html.twig", 5)->display($context);
        // line 6
        echo "    </div>
    <div class=\"container\">
        <h1>ADD User</h1>
        <div class=\"col-8\">
    ";
        // line 10
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 10, $this->source); })()), 'form_start');
        echo "
        <div class=\"form-group\">
    ";
        // line 12
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 12, $this->source); })()), "FirstName", [], "any", false, false, false, 12), 'row');
        echo "
        </div>
        <div class=\"form-group\">
    ";
        // line 15
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 15, $this->source); })()), "LastName", [], "any", false, false, false, 15), 'row');
        echo "
        </div>
        <div class=\"form-group\">
    ";
        // line 18
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 18, $this->source); })()), "email", [], "any", false, false, false, 18), 'row');
        echo "
        </div>
            <div class=\"form-group\">
                ";
        // line 21
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 21, $this->source); })()), "roles", [], "any", false, false, false, 21), 'row');
        echo "
            </div>
        <div class=\"form-group\">
    ";
        // line 24
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 24, $this->source); })()), "password", [], "any", false, false, false, 24), "first", [], "any", false, false, false, 24), 'row');
        echo "
    ";
        // line 25
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 25, $this->source); })()), "password", [], "any", false, false, false, 25), "second", [], "any", false, false, false, 25), 'row');
        echo "
        </div>
    <button class=\"btn btn-success\" type=\"submit\">ADD USER</button>
    ";
        // line 28
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 28, $this->source); })()), 'form_end');
        echo "
    </div>
    </div>
</div>
    ";
        // line 32
        $this->loadTemplate("include/footer.html.twig", "add_user/index.html.twig", 32)->display($context);
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "add_user/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  104 => 32,  97 => 28,  91 => 25,  87 => 24,  81 => 21,  75 => 18,  69 => 15,  63 => 12,  58 => 10,  52 => 6,  50 => 5,  45 => 2,  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% include 'include/header.html.twig' %}

<div class=\"row\">
    <div class=\"col-1\">
        {% include 'include/adminpanel.html.twig' %}
    </div>
    <div class=\"container\">
        <h1>ADD User</h1>
        <div class=\"col-8\">
    {{ form_start(form) }}
        <div class=\"form-group\">
    {{ form_row(form.FirstName) }}
        </div>
        <div class=\"form-group\">
    {{ form_row(form.LastName) }}
        </div>
        <div class=\"form-group\">
    {{ form_row(form.email) }}
        </div>
            <div class=\"form-group\">
                {{ form_row(form.roles) }}
            </div>
        <div class=\"form-group\">
    {{ form_row(form.password.first) }}
    {{ form_row(form.password.second) }}
        </div>
    <button class=\"btn btn-success\" type=\"submit\">ADD USER</button>
    {{ form_end(form) }}
    </div>
    </div>
</div>
    {% include 'include/footer.html.twig' %}
", "add_user/index.html.twig", "/usr/share/nginx/html/sybook/templates/add_user/index.html.twig");
    }
}
