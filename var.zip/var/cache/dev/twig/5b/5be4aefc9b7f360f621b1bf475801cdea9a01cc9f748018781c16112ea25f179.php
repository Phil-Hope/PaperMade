<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* books/new.html.twig */
class __TwigTemplate_12083aec8ae9594ff10c1f94f0667ce70b5231a917a6d33f2322bee383b74a17 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "books/new.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "books/new.html.twig"));

        // line 1
        $this->loadTemplate("include/header.html.twig", "books/new.html.twig", 1)->display($context);
        // line 2
        echo "
    <div class=\"row\">
        <div class=\"col-1\">
            ";
        // line 5
        $this->loadTemplate("include/adminpanel.html.twig", "books/new.html.twig", 5)->display($context);
        // line 6
        echo "        </div>
        <div class=\"col-4\">
            <h1>ADD BOOKS</h1>
                <h5 style=\"color: #721c24;\">Please ensure the author has been added, and exists in the database before adding a book.</h5>


            ";
        // line 12
        echo twig_include($this->env, $context, "books/_form.html.twig");
        echo "


        </div>
        <div class=\"3\">
            <table class=\"table\">
                <h1>Author IDs</h1>
                <thead>
                <tr>
                    <th>Author Id:</th>
                    <th>Full Name</th>
                </tr>
                </thead>
                <tbody>
                ";
        // line 26
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["authors"]) || array_key_exists("authors", $context) ? $context["authors"] : (function () { throw new RuntimeError('Variable "authors" does not exist.', 26, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["author"]) {
            // line 27
            echo "                    <tr>
                        <td>";
            // line 28
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["author"], "id", [], "any", false, false, false, 28), "html", null, true);
            echo "</td>
                        <td>";
            // line 29
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["author"], "Name", [], "any", false, false, false, 29), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["author"], "Surname", [], "any", false, false, false, 29), "html", null, true);
            echo "</td>
                    </tr>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['author'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 32
        echo "                </tbody>
            </table>
        </div>
        <div class=\"col-4\" style=\"overflow-x:scroll; max-height: 30vw;\">
                <h2>Books In Database</h2>
                <table class=\"table\" >
                    ";
        // line 38
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["books"]) || array_key_exists("books", $context) ? $context["books"] : (function () { throw new RuntimeError('Variable "books" does not exist.', 38, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["book"]) {
            // line 39
            echo "                    <tr>
                        <td><h1>";
            // line 40
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["book"], "BookTitle", [], "any", false, false, false, 40), "html", null, true);
            echo "</h1></td>
                        <td><a href=\"";
            // line 41
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("books_show", ["id" => twig_get_attribute($this->env, $this->source, $context["book"], "id", [], "any", false, false, false, 41)]), "html", null, true);
            echo "\"><img class=\"img-thumbnail\" style=\"max-height: 10vw; width: auto\" src=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["book"], "coverImagePath", [], "any", false, false, false, 41), "html", null, true);
            echo "\"></a></td>
                        </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['book'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 44
        echo "                </table>
        </div>
    </div>
</div>
";
        // line 48
        $this->loadTemplate("include/footer.html.twig", "books/new.html.twig", 48)->display($context);
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "books/new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  135 => 48,  129 => 44,  118 => 41,  114 => 40,  111 => 39,  107 => 38,  99 => 32,  88 => 29,  84 => 28,  81 => 27,  77 => 26,  60 => 12,  52 => 6,  50 => 5,  45 => 2,  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% include 'include/header.html.twig' %}

    <div class=\"row\">
        <div class=\"col-1\">
            {% include 'include/adminpanel.html.twig' %}
        </div>
        <div class=\"col-4\">
            <h1>ADD BOOKS</h1>
                <h5 style=\"color: #721c24;\">Please ensure the author has been added, and exists in the database before adding a book.</h5>


            {{ include('books/_form.html.twig') }}


        </div>
        <div class=\"3\">
            <table class=\"table\">
                <h1>Author IDs</h1>
                <thead>
                <tr>
                    <th>Author Id:</th>
                    <th>Full Name</th>
                </tr>
                </thead>
                <tbody>
                {% for author in authors %}
                    <tr>
                        <td>{{ author.id }}</td>
                        <td>{{ author.Name }} {{ author.Surname }}</td>
                    </tr>
                {% endfor %}
                </tbody>
            </table>
        </div>
        <div class=\"col-4\" style=\"overflow-x:scroll; max-height: 30vw;\">
                <h2>Books In Database</h2>
                <table class=\"table\" >
                    {% for book in books %}
                    <tr>
                        <td><h1>{{ book.BookTitle }}</h1></td>
                        <td><a href=\"{{ path('books_show', {'id': book.id}) }}\"><img class=\"img-thumbnail\" style=\"max-height: 10vw; width: auto\" src=\"{{ book.coverImagePath }}\"></a></td>
                        </tr>
                    {% endfor %}
                </table>
        </div>
    </div>
</div>
{% include 'include/footer.html.twig' %}
", "books/new.html.twig", "/usr/share/nginx/html/sybook/templates/books/new.html.twig");
    }
}
