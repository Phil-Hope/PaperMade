<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* change_log/index.html.twig */
class __TwigTemplate_3767962fef5aef873412b10eb116368f3f2542b2d5e1812a6f1d04ae0b508f8d extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "change_log/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "change_log/index.html.twig"));

        // line 1
        $this->loadTemplate("include/header.html.twig", "change_log/index.html.twig", 1)->display($context);
        // line 2
        echo "<style>
    th
    {
        font-size: 0.9vw;
    }
    td
    {
        font-size: 0.7vw;
    }
</style>
<div class=\"container-fluid\">
    <div class=\"row\">
        <div class=\"col-2\">
            ";
        // line 15
        $this->loadTemplate("include/adminpanel.html.twig", "change_log/index.html.twig", 15)->display($context);
        // line 16
        echo "        </div>
        <div class=\"col-10\">
            <div class=\"container\" style=\"overflow-x:auto; max-height: 70vw;\">
    <h1>ChangeLog index</h1>

    <table class=\"table\">
        <thead>
            <tr>
                <th>Date Created</th>
                <th>Date Updated</th>
                <th>Book Changed</th>
                <th>Changed By</th>
            </tr>
        </thead>
        <tbody>
        ";
        // line 31
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["books"]) || array_key_exists("books", $context) ? $context["books"] : (function () { throw new RuntimeError('Variable "books" does not exist.', 31, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["book"]) {
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["users"]) || array_key_exists("users", $context) ? $context["users"] : (function () { throw new RuntimeError('Variable "users" does not exist.', 31, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["user"]) {
                // line 32
                echo "        ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["change_logs"]) || array_key_exists("change_logs", $context) ? $context["change_logs"] : (function () { throw new RuntimeError('Variable "change_logs" does not exist.', 32, $this->source); })()));
                foreach ($context['_seq'] as $context["_key"] => $context["change_log"]) {
                    if (0 === twig_compare(twig_get_attribute($this->env, $this->source, $context["change_log"], "BookChanged", [], "any", false, false, false, 32), twig_get_attribute($this->env, $this->source, $context["book"], "id", [], "any", false, false, false, 32))) {
                        if (0 === twig_compare(twig_get_attribute($this->env, $this->source, $context["change_log"], "ChangedBy", [], "any", false, false, false, 32), twig_get_attribute($this->env, $this->source, $context["user"], "id", [], "any", false, false, false, 32))) {
                            // line 33
                            echo "

                <tr>
                    <td>";
                            // line 36
                            ((twig_test_empty(twig_get_attribute($this->env, $this->source, $context["change_log"], "DateCreated", [], "any", false, false, false, 36))) ? (print (twig_escape_filter($this->env, $this->extensions['Twig\Extra\Intl\IntlExtension']->formatDateTime($this->env, ""), "html", null, true))) : (print ("")));
                            echo "</td>

                <td>";
                            // line 38
                            ((twig_test_empty(twig_get_attribute($this->env, $this->source, $context["change_log"], "DateUpdated", [], "any", false, false, false, 38))) ? (print (twig_escape_filter($this->env, $this->extensions['Twig\Extra\Intl\IntlExtension']->formatDateTime($this->env, ""), "html", null, true))) : (print ("")));
                            echo "</td>

                    <td><a href=\"";
                            // line 40
                            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("books_show", ["id" => twig_get_attribute($this->env, $this->source, $context["book"], "id", [], "any", false, false, false, 40)]), "html", null, true);
                            echo "\">";
                            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["book"], "BookTitle", [], "any", false, false, false, 40), "html", null, true);
                            echo "</a></td>

      <td>  ";
                            // line 42
                            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "FirstName", [], "any", false, false, false, 42), "html", null, true);
                            echo " ";
                            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "LastName", [], "any", false, false, false, 42), "html", null, true);
                            echo "</td>
                    ";
                        }
                        // line 43
                        echo "   ";
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['change_log'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['user'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['book'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 44
        echo "        </tr>

        </tbody>
    </table>
        </div>
    </div>
    </div>
</div>
            ";
        // line 52
        $this->loadTemplate("include/footer.html.twig", "change_log/index.html.twig", 52)->display($context);
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "change_log/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  147 => 52,  137 => 44,  122 => 43,  115 => 42,  108 => 40,  103 => 38,  98 => 36,  93 => 33,  86 => 32,  79 => 31,  62 => 16,  60 => 15,  45 => 2,  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% include 'include/header.html.twig' %}
<style>
    th
    {
        font-size: 0.9vw;
    }
    td
    {
        font-size: 0.7vw;
    }
</style>
<div class=\"container-fluid\">
    <div class=\"row\">
        <div class=\"col-2\">
            {% include 'include/adminpanel.html.twig' %}
        </div>
        <div class=\"col-10\">
            <div class=\"container\" style=\"overflow-x:auto; max-height: 70vw;\">
    <h1>ChangeLog index</h1>

    <table class=\"table\">
        <thead>
            <tr>
                <th>Date Created</th>
                <th>Date Updated</th>
                <th>Book Changed</th>
                <th>Changed By</th>
            </tr>
        </thead>
        <tbody>
        {% for book in books %}{% for user in users %}
        {% for change_log in change_logs %}{% if change_log.BookChanged == book.id %}{% if change_log.ChangedBy == user.id %}


                <tr>
                    <td>{{ change_log.DateCreated is empty ? \"\" | format_datetime }}</td>

                <td>{{ change_log.DateUpdated is empty ? \"\" | format_datetime }}</td>

                    <td><a href=\"{{ path('books_show', {'id': book.id}) }}\">{{ book.BookTitle }}</a></td>

      <td>  {{ user.FirstName}} {{ user.LastName }}</td>
                    {% endif %}   {% endif %}{% endfor %}{% endfor %}{% endfor %}
        </tr>

        </tbody>
    </table>
        </div>
    </div>
    </div>
</div>
            {% include 'include/footer.html.twig' %}
", "change_log/index.html.twig", "/usr/share/nginx/html/sybook/templates/change_log/index.html.twig");
    }
}
