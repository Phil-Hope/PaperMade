<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* security/login.html.twig */
class __TwigTemplate_e1f0ea95847ca8840956f2a1f78a7bf5aeee41a6f35a18e9a84a107deb557b7c extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "security/login.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "security/login.html.twig"));

        // line 1
        $this->loadTemplate("include/header.html.twig", "security/login.html.twig", 1)->display($context);
        // line 2
        echo "<div class=\"container\" style=\"width: 50%;\">

<form method=\"post\" style=\"margin-top: 10vw; margin-bottom: 10vw;\">
    <h1 style=\"margin-bottom: 2vw;\">ADMIN LOGIN</h1>
    ";
        // line 6
        if ((isset($context["error"]) || array_key_exists("error", $context) ? $context["error"] : (function () { throw new RuntimeError('Variable "error" does not exist.', 6, $this->source); })())) {
            // line 7
            echo "        <div class=\"alert alert-danger\">";
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(twig_get_attribute($this->env, $this->source, (isset($context["error"]) || array_key_exists("error", $context) ? $context["error"] : (function () { throw new RuntimeError('Variable "error" does not exist.', 7, $this->source); })()), "messageKey", [], "any", false, false, false, 7), twig_get_attribute($this->env, $this->source, (isset($context["error"]) || array_key_exists("error", $context) ? $context["error"] : (function () { throw new RuntimeError('Variable "error" does not exist.', 7, $this->source); })()), "messageData", [], "any", false, false, false, 7), "security"), "html", null, true);
            echo "</div>
    ";
        }
        // line 9
        echo "
    ";
        // line 10
        if (twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 10, $this->source); })()), "user", [], "any", false, false, false, 10)) {
            // line 11
            echo "        <div class=\"mb-3\">
            You are logged in as ";
            // line 12
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 12, $this->source); })()), "user", [], "any", false, false, false, 12), "username", [], "any", false, false, false, 12), "html", null, true);
            echo ", <a href=\"";
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_logout");
            echo "\">Logout</a>
        </div>
    ";
        }
        // line 15
        echo "

    <div class=\"row\">
        <div class=\"col-0.5\">
            <label for=\"inputEmail\"><svg class=\"bi bi-envelope-fill\" width=\"1vw\" height=\"1vw\" viewBox=\"0 0 16 16\" fill=\"currentColor\" xmlns=\"http://www.w3.org/2000/svg\">
                    <path fill-rule=\"evenodd\" d=\"M.05 3.555A2 2 0 0 1 2 2h12a2 2 0 0 1 1.95 1.555L8 8.414.05 3.555zM0 4.697v7.104l5.803-3.558L0 4.697zM6.761 8.83l-6.57 4.027A2 2 0 0 0 2 14h12a2 2 0 0 0 1.808-1.144l-6.57-4.027L8 9.586l-1.239-.757zm3.436-.586L16 11.801V4.697l-5.803 3.546z\"/>
                </svg></label>
        </div>
        <div class=\"col-6\">
    <input  type=\"email\" value=\"";
        // line 24
        echo twig_escape_filter($this->env, (isset($context["last_username"]) || array_key_exists("last_username", $context) ? $context["last_username"] : (function () { throw new RuntimeError('Variable "last_username" does not exist.', 24, $this->source); })()), "html", null, true);
        echo "\" name=\"email\" placeholder=\"@email\" id=\"inputEmail\" class=\"form-control mb-2 mr-sm-2\" required autofocus>
        <div class=\"valid-feedback\">Valid.</div>
        <div class=\"invalid-feedback\">A valid email must be entered</div>
        </div>
    </div>

<div class=\"row\">
    <div class=\"col-0.5\">
    <label for=\"inputPassword\"><svg class=\"bi bi-lock-fill\" width=\"1vw\" height=\"1vw\" viewBox=\"0 0 16 16\" fill=\"currentColor\" xmlns=\"http://www.w3.org/2000/svg\">
            <rect width=\"11\" height=\"9\" x=\"2.5\" y=\"7\" rx=\"2\"/>
            <path fill-rule=\"evenodd\" d=\"M4.5 4a3.5 3.5 0 1 1 7 0v3h-1V4a2.5 2.5 0 0 0-5 0v3h-1V4z\"/>
        </svg></label>
    </div>
    <div class=\"col-6\">
    <input type=\"password\" name=\"password\" id=\"inputPassword\" placeholder=\"password\" class=\"form-control mb-2 mr-sm-2\" required>
        <div class=\"valid-feedback\">Valid.</div>
        <div class=\"invalid-feedback\">Password field can not be blank</div>
    </div>
</div>
    <input type=\"hidden\" name=\"_csrf_token\"
           value=\"";
        // line 44
        echo twig_escape_filter($this->env, $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderCsrfToken("authenticate"), "html", null, true);
        echo "\">

    ";
        // line 56
        echo "<div class=\"row\" style=\"margin-top: 1vw;\">
    <div clas=\"col-0.5\">
    <button class=\"btn btn-lg btn-primary\" type=\"submit\">
        Sign in
    </button>
</div></div>
</form>
</div>
";
        // line 64
        $this->loadTemplate("include/footer.html.twig", "security/login.html.twig", 64)->display($context);
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "security/login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  124 => 64,  114 => 56,  109 => 44,  86 => 24,  75 => 15,  67 => 12,  64 => 11,  62 => 10,  59 => 9,  53 => 7,  51 => 6,  45 => 2,  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% include 'include/header.html.twig' %}
<div class=\"container\" style=\"width: 50%;\">

<form method=\"post\" style=\"margin-top: 10vw; margin-bottom: 10vw;\">
    <h1 style=\"margin-bottom: 2vw;\">ADMIN LOGIN</h1>
    {% if error %}
        <div class=\"alert alert-danger\">{{ error.messageKey|trans(error.messageData, 'security') }}</div>
    {% endif %}

    {% if app.user %}
        <div class=\"mb-3\">
            You are logged in as {{ app.user.username }}, <a href=\"{{ path('app_logout') }}\">Logout</a>
        </div>
    {% endif %}


    <div class=\"row\">
        <div class=\"col-0.5\">
            <label for=\"inputEmail\"><svg class=\"bi bi-envelope-fill\" width=\"1vw\" height=\"1vw\" viewBox=\"0 0 16 16\" fill=\"currentColor\" xmlns=\"http://www.w3.org/2000/svg\">
                    <path fill-rule=\"evenodd\" d=\"M.05 3.555A2 2 0 0 1 2 2h12a2 2 0 0 1 1.95 1.555L8 8.414.05 3.555zM0 4.697v7.104l5.803-3.558L0 4.697zM6.761 8.83l-6.57 4.027A2 2 0 0 0 2 14h12a2 2 0 0 0 1.808-1.144l-6.57-4.027L8 9.586l-1.239-.757zm3.436-.586L16 11.801V4.697l-5.803 3.546z\"/>
                </svg></label>
        </div>
        <div class=\"col-6\">
    <input  type=\"email\" value=\"{{ last_username }}\" name=\"email\" placeholder=\"@email\" id=\"inputEmail\" class=\"form-control mb-2 mr-sm-2\" required autofocus>
        <div class=\"valid-feedback\">Valid.</div>
        <div class=\"invalid-feedback\">A valid email must be entered</div>
        </div>
    </div>

<div class=\"row\">
    <div class=\"col-0.5\">
    <label for=\"inputPassword\"><svg class=\"bi bi-lock-fill\" width=\"1vw\" height=\"1vw\" viewBox=\"0 0 16 16\" fill=\"currentColor\" xmlns=\"http://www.w3.org/2000/svg\">
            <rect width=\"11\" height=\"9\" x=\"2.5\" y=\"7\" rx=\"2\"/>
            <path fill-rule=\"evenodd\" d=\"M4.5 4a3.5 3.5 0 1 1 7 0v3h-1V4a2.5 2.5 0 0 0-5 0v3h-1V4z\"/>
        </svg></label>
    </div>
    <div class=\"col-6\">
    <input type=\"password\" name=\"password\" id=\"inputPassword\" placeholder=\"password\" class=\"form-control mb-2 mr-sm-2\" required>
        <div class=\"valid-feedback\">Valid.</div>
        <div class=\"invalid-feedback\">Password field can not be blank</div>
    </div>
</div>
    <input type=\"hidden\" name=\"_csrf_token\"
           value=\"{{ csrf_token('authenticate') }}\">

    {#
        Uncomment this section and add a remember_me option below your firewall to activate remember me functionality.
        See https://symfony.com/doc/current/security/remember_me.html

        <div class=\"checkbox mb-3\">
            <label>
                <input type=\"checkbox\" name=\"_remember_me\"> Remember me
            </label>
        </div>
    #}
<div class=\"row\" style=\"margin-top: 1vw;\">
    <div clas=\"col-0.5\">
    <button class=\"btn btn-lg btn-primary\" type=\"submit\">
        Sign in
    </button>
</div></div>
</form>
</div>
{% include 'include/footer.html.twig' %}
", "security/login.html.twig", "/usr/share/nginx/html/sybook/templates/security/login.html.twig");
    }
}
