<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* admin/index.html.twig */
class __TwigTemplate_8da51ab73d1915584dcc37248a8a73935dbcddc43b42ab19fe3f5dd66ef0b493 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "admin/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "admin/index.html.twig"));

        // line 1
        $this->loadTemplate("include/header.html.twig", "admin/index.html.twig", 1)->display($context);
        // line 2
        echo "<style>
    th
    {
        font-size: 0.9vw;
    }
    td
    {
        font-size: 0.7vw;
    }
</style>
<div class=\"container-fluid\">
    <div class=\"row\">
        <div class=\"col-2\">
            ";
        // line 15
        $this->loadTemplate("include/adminpanel.html.twig", "admin/index.html.twig", 15)->display($context);
        // line 16
        echo "        </div>
        <div class=\"col-10\">
                <div class=\"container\" style=\"overflow-x:auto; max-height: 70vw;\">
                    <h1>BOOKS INVENTORY</h1>
                    <table class=\"table table-hover\">
                        <thead class=\"thead-light\">
                        <tr>
                            <th>BookTitle</th>
                            <th>OriginalTitle</th>
                            <th>Genre</th>
                            <th>LanguageWritten</th>
                            <th>CoverImagePath</th>
                            <th>Author</th>
                        </tr>
                        </thead>
                        ";
        // line 31
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["books"]) || array_key_exists("books", $context) ? $context["books"] : (function () { throw new RuntimeError('Variable "books" does not exist.', 31, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["book"]) {
            // line 32
            echo "                        <tr>
                            <tbody>
                        <td><a href=\"";
            // line 34
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("books_show", ["id" => twig_get_attribute($this->env, $this->source, $context["book"], "id", [], "any", false, false, false, 34)]), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["book"], "BookTitle", [], "any", false, false, false, 34), "html", null, true);
            echo "</a></td>
                        <td>";
            // line 35
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["book"], "OriginalTitle", [], "any", false, false, false, 35), "html", null, true);
            echo "</td>
                        <td>";
            // line 36
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["book"], "Genre", [], "any", false, false, false, 36), "html", null, true);
            echo "</td>
                        <td>";
            // line 37
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["book"], "LanguageWritten", [], "any", false, false, false, 37), "html", null, true);
            echo "</td>
                        <td><img class=\"img-thumbnail\" style=\"max-height: 10vw; width: auto;\" src=\"";
            // line 38
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["book"], "coverImagePath", [], "any", false, false, false, 38), "html", null, true);
            echo "\"></td>
                        ";
            // line 39
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["author"]) || array_key_exists("author", $context) ? $context["author"] : (function () { throw new RuntimeError('Variable "author" does not exist.', 39, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["authors"]) {
                // line 40
                echo "                            ";
                if (0 === twig_compare(twig_get_attribute($this->env, $this->source, $context["book"], "Author", [], "any", false, false, false, 40), twig_get_attribute($this->env, $this->source, (isset($context["author"]) || array_key_exists("author", $context) ? $context["author"] : (function () { throw new RuntimeError('Variable "author" does not exist.', 40, $this->source); })()), "id", [], "any", false, false, false, 40))) {
                    // line 41
                    echo "                                <td><a href=\"";
                    echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("author_show", ["id" => twig_get_attribute($this->env, $this->source, (isset($context["author"]) || array_key_exists("author", $context) ? $context["author"] : (function () { throw new RuntimeError('Variable "author" does not exist.', 41, $this->source); })()), "id", [], "any", false, false, false, 41)]), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["author"]) || array_key_exists("author", $context) ? $context["author"] : (function () { throw new RuntimeError('Variable "author" does not exist.', 41, $this->source); })()), "Name", [], "any", false, false, false, 41), "html", null, true);
                    echo " ";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["author"]) || array_key_exists("author", $context) ? $context["author"] : (function () { throw new RuntimeError('Variable "author" does not exist.', 41, $this->source); })()), "Surname", [], "any", false, false, false, 41), "html", null, true);
                    echo "</a></td>
                            ";
                }
                // line 43
                echo "                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['authors'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 44
            echo "                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['book'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 45
        echo "                            </tbody>
                        </tr>
                    </table></div>
            </div>
        </div>
</div>
";
        // line 51
        $this->loadTemplate("include/footer.html.twig", "admin/index.html.twig", 51)->display($context);
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "admin/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  146 => 51,  138 => 45,  132 => 44,  126 => 43,  116 => 41,  113 => 40,  109 => 39,  105 => 38,  101 => 37,  97 => 36,  93 => 35,  87 => 34,  83 => 32,  79 => 31,  62 => 16,  60 => 15,  45 => 2,  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% include 'include/header.html.twig' %}
<style>
    th
    {
        font-size: 0.9vw;
    }
    td
    {
        font-size: 0.7vw;
    }
</style>
<div class=\"container-fluid\">
    <div class=\"row\">
        <div class=\"col-2\">
            {% include 'include/adminpanel.html.twig' %}
        </div>
        <div class=\"col-10\">
                <div class=\"container\" style=\"overflow-x:auto; max-height: 70vw;\">
                    <h1>BOOKS INVENTORY</h1>
                    <table class=\"table table-hover\">
                        <thead class=\"thead-light\">
                        <tr>
                            <th>BookTitle</th>
                            <th>OriginalTitle</th>
                            <th>Genre</th>
                            <th>LanguageWritten</th>
                            <th>CoverImagePath</th>
                            <th>Author</th>
                        </tr>
                        </thead>
                        {% for book in books %}
                        <tr>
                            <tbody>
                        <td><a href=\"{{ path('books_show', {'id': book.id}) }}\">{{ book.BookTitle }}</a></td>
                        <td>{{ book.OriginalTitle }}</td>
                        <td>{{ book.Genre }}</td>
                        <td>{{ book.LanguageWritten }}</td>
                        <td><img class=\"img-thumbnail\" style=\"max-height: 10vw; width: auto;\" src=\"{{ book.coverImagePath }}\"></td>
                        {% for authors in author %}
                            {% if book.Author == author.id  %}
                                <td><a href=\"{{ path('author_show', {'id': author.id}) }}\">{{ author.Name }} {{ author.Surname }}</a></td>
                            {% endif %}
                            {% endfor %}
                        {% endfor %}
                            </tbody>
                        </tr>
                    </table></div>
            </div>
        </div>
</div>
{% include 'include/footer.html.twig' %}
", "admin/index.html.twig", "/usr/share/nginx/html/sybook/templates/admin/index.html.twig");
    }
}
