<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* books/edit.html.twig */
class __TwigTemplate_5194d9a5c8716528c451364c43de742ad9c830b8076d15a664ad8ff19c6bce86 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "books/edit.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "books/edit.html.twig"));

        // line 1
        $this->loadTemplate("include/header.html.twig", "books/edit.html.twig", 1)->display($context);
        // line 2
        echo "
    <h1>Edit Books</h1>

<div class=\"row\">
    <div class=\"col-1\">
        ";
        // line 7
        $this->loadTemplate("include/adminpanel.html.twig", "books/edit.html.twig", 7)->display($context);
        // line 8
        echo "    </div>
    <div class=\"container\">
        <div class=\"col-8\">

    ";
        // line 12
        echo twig_include($this->env, $context, "books/_form.html.twig", ["button_label" => "Update"]);
        echo "
            ";
        // line 13
        echo twig_include($this->env, $context, "books/_delete_form.html.twig");
        echo "
        </div>
    </div>
</div>
</div>
";
        // line 18
        $this->loadTemplate("include/footer.html.twig", "books/edit.html.twig", 18)->display($context);
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "books/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 18,  64 => 13,  60 => 12,  54 => 8,  52 => 7,  45 => 2,  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% include 'include/header.html.twig' %}

    <h1>Edit Books</h1>

<div class=\"row\">
    <div class=\"col-1\">
        {% include 'include/adminpanel.html.twig' %}
    </div>
    <div class=\"container\">
        <div class=\"col-8\">

    {{ include('books/_form.html.twig', {'button_label': 'Update'}) }}
            {{ include('books/_delete_form.html.twig') }}
        </div>
    </div>
</div>
</div>
{% include 'include/footer.html.twig' %}
", "books/edit.html.twig", "/usr/share/nginx/html/sybook/templates/books/edit.html.twig");
    }
}
