<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* include/homepage.html.twig */
class __TwigTemplate_7135d875bdd5167d63b810bc73f7c65136369b1e6666174e91ef11e14e006a08 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'main' => [$this, 'block_main'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "include/homepage.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "include/homepage.html.twig"));

        // line 1
        $this->displayBlock('main', $context, $blocks);
        // line 37
        echo "
";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 1
    public function block_main($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "main"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "main"));

        // line 2
        echo "    <img class=\"img-fluid\" style=\" width:100%;\" src=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/animation.gif"), "html", null, true);
        echo "\">

    <div class=\"container\">
        <div class=\"row align-items-center\">
            <div class=\"col-md-6\"><img class=\"img-thumbnail\" src=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/front.jpg"), "html", null, true);
        echo "\" alt=\"frontpage_img\">
            </div>
            <div class=\"col-md-6\">
                <h3>PaperMadeBooks Inc</h3>
                <div class=\"getting-started-info\">
                    <p>Here is your one stop destination to find the perfect book</p>
                </div>
            </div>
        </div>
    </div>
    <div class=\"container\">
        <div class=\"carousel slide\" data-ride=\"carousel\" id=\"carousel-1\">
            <div class=\"carousel-inner\" role=\"listbox\">
                <div class=\"carousel-item active\"><img class=\"w-100 d-block\" src=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/slide1.png"), "html", null, true);
        echo "\" alt=\"Slide Image\"></div>
                <div class=\"carousel-item\"><img class=\"w-100 d-block\" src=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/slide2.png"), "html", null, true);
        echo "\" alt=\"Slide Image\"></div>
                <div class=\"carousel-item\"><img class=\"w-100 d-block\" src=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/slide3.png"), "html", null, true);
        echo "\" alt=\"Slide Image\"></div>
            </div>
            <div><a class=\"carousel-control-prev\" href=\"#carousel-1\" role=\"button\" data-slide=\"prev\"><span class=\"carousel-control-prev-icon\"></span>
                    <span class=\"sr-only\">Previous</span></a>
                <a class=\"carousel-control-next\" href=\"#carousel-1\" role=\"button\"
                   data-slide=\"next\"><span class=\"carousel-control-next-icon\"></span><span class=\"sr-only\">Next</span></a></div>
            <ol class=\"carousel-indicators\">
                <li data-target=\"#carousel-1\" data-slide-to=\"0\" class=\"active\"></li>
                <li data-target=\"#carousel-1\" data-slide-to=\"1\"></li>
                <li data-target=\"#carousel-1\" data-slide-to=\"2\"></li>
            </ol>
        </div>
    </div>
    </main>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "include/homepage.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  99 => 21,  95 => 20,  91 => 19,  75 => 6,  67 => 2,  57 => 1,  46 => 37,  44 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% block main %}
    <img class=\"img-fluid\" style=\" width:100%;\" src=\"{{ asset('img/animation.gif') }}\">

    <div class=\"container\">
        <div class=\"row align-items-center\">
            <div class=\"col-md-6\"><img class=\"img-thumbnail\" src=\"{{ asset('img/front.jpg') }}\" alt=\"frontpage_img\">
            </div>
            <div class=\"col-md-6\">
                <h3>PaperMadeBooks Inc</h3>
                <div class=\"getting-started-info\">
                    <p>Here is your one stop destination to find the perfect book</p>
                </div>
            </div>
        </div>
    </div>
    <div class=\"container\">
        <div class=\"carousel slide\" data-ride=\"carousel\" id=\"carousel-1\">
            <div class=\"carousel-inner\" role=\"listbox\">
                <div class=\"carousel-item active\"><img class=\"w-100 d-block\" src=\"{{ asset('img/slide1.png') }}\" alt=\"Slide Image\"></div>
                <div class=\"carousel-item\"><img class=\"w-100 d-block\" src=\"{{ asset('img/slide2.png') }}\" alt=\"Slide Image\"></div>
                <div class=\"carousel-item\"><img class=\"w-100 d-block\" src=\"{{ asset('img/slide3.png') }}\" alt=\"Slide Image\"></div>
            </div>
            <div><a class=\"carousel-control-prev\" href=\"#carousel-1\" role=\"button\" data-slide=\"prev\"><span class=\"carousel-control-prev-icon\"></span>
                    <span class=\"sr-only\">Previous</span></a>
                <a class=\"carousel-control-next\" href=\"#carousel-1\" role=\"button\"
                   data-slide=\"next\"><span class=\"carousel-control-next-icon\"></span><span class=\"sr-only\">Next</span></a></div>
            <ol class=\"carousel-indicators\">
                <li data-target=\"#carousel-1\" data-slide-to=\"0\" class=\"active\"></li>
                <li data-target=\"#carousel-1\" data-slide-to=\"1\"></li>
                <li data-target=\"#carousel-1\" data-slide-to=\"2\"></li>
            </ol>
        </div>
    </div>
    </main>

{% endblock %}

", "include/homepage.html.twig", "/usr/share/nginx/html/sybook/templates/include/homepage.html.twig");
    }
}
