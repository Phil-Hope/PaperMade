<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* include/adminpanel.html.twig */
class __TwigTemplate_805003a4f5eca5ef7432744b5b7c34ce7f0bb02939a61a7b9ca56600144d922a extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'adminpanel' => [$this, 'block_adminpanel'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "include/adminpanel.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "include/adminpanel.html.twig"));

        // line 1
        $this->displayBlock('adminpanel', $context, $blocks);
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function block_adminpanel($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "adminpanel"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "adminpanel"));

        // line 2
        echo "    <style>
        label
        {
            font-size: 0.8vw;
        }
    </style>
<nav class=\"navbar navbar-light bg-light\">
    <ul class=\"navbar-nav\">
                    <li class=\"nav-item\">
                        <a class=\"nav-link active\" href=\"";
        // line 11
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("admin");
        echo "\">
                            <label><strong>ADMIN MENU</strong></label>
                            <span class=\"sr-only\">(current)</span>
                        </a>
                    </li>
        <li class=\"nav-item\">
            <a class=\"nav-link active\" href=\"#\">
                <label>WELCOME <hr/><strong>";
        // line 18
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 18, $this->source); })()), "user", [], "any", false, false, false, 18), "FirstName", [], "any", false, false, false, 18), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 18, $this->source); })()), "user", [], "any", false, false, false, 18), "LastName", [], "any", false, false, false, 18), "html", null, true);
        echo "</strong></label>
                <span class=\"sr-only\">(current)</span>
            </a>
        </li>
                    <li class=\"nav-item\">
                        <a class=\"nav-link\" href=\"";
        // line 23
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("books_index");
        echo "\">
                            <label>VIEW Books</label>
                        </a>
                    </li>
                    <li class=\"nav-item\">
                        <a class=\"nav-link\" href=\"";
        // line 28
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("books_new");
        echo "\">
                            <span data-feather=\"shopping-cart\"></span>
                            <label>ADD Book</label>
                        </a>
                    </li>
                    <li class=\"nav-item\">
                        <a class=\"nav-link\" href=\"";
        // line 34
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("author_index");
        echo "\">
                            <label>VIEW Authors</label>
                        </a>
                    </li>
                    <li class=\"nav-item\">
                        <a class=\"nav-link\" href=\"";
        // line 39
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("author_new");
        echo "\">
                            <label>ADD Author</label>
                        </a>
                    </li>
        ";
        // line 43
        if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_SUPER_USER")) {
            // line 44
            echo "                    <li class=\"nav-item\">
                        <a class=\"nav-link\" href=\"";
            // line 45
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("change_log_index");
            echo "\">
                          <label>ChangeLog</label>
                        </a>
                    </li>
        </li>
        <li class=\"nav-item\">
            <a class=\"nav-link\" href=\"";
            // line 51
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("add_user");
            echo "\">
               <label>ADD User</label>
            </a>
        </li>
        <li class=\"nav-item\">
            <a class=\"nav-link\" href=\"";
            // line 56
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getUrl("users_index");
            echo "\">
                <label>VIEW/EDIT User</label>
            </a>
        </li>
        ";
        }
        // line 61
        echo "                </ul>
                </nav>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "include/adminpanel.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  156 => 61,  148 => 56,  140 => 51,  131 => 45,  128 => 44,  126 => 43,  119 => 39,  111 => 34,  102 => 28,  94 => 23,  84 => 18,  74 => 11,  63 => 2,  44 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% block adminpanel %}
    <style>
        label
        {
            font-size: 0.8vw;
        }
    </style>
<nav class=\"navbar navbar-light bg-light\">
    <ul class=\"navbar-nav\">
                    <li class=\"nav-item\">
                        <a class=\"nav-link active\" href=\"{{ url('admin') }}\">
                            <label><strong>ADMIN MENU</strong></label>
                            <span class=\"sr-only\">(current)</span>
                        </a>
                    </li>
        <li class=\"nav-item\">
            <a class=\"nav-link active\" href=\"#\">
                <label>WELCOME <hr/><strong>{{ app.user.FirstName }} {{ app.user.LastName }}</strong></label>
                <span class=\"sr-only\">(current)</span>
            </a>
        </li>
                    <li class=\"nav-item\">
                        <a class=\"nav-link\" href=\"{{ url('books_index') }}\">
                            <label>VIEW Books</label>
                        </a>
                    </li>
                    <li class=\"nav-item\">
                        <a class=\"nav-link\" href=\"{{ url('books_new') }}\">
                            <span data-feather=\"shopping-cart\"></span>
                            <label>ADD Book</label>
                        </a>
                    </li>
                    <li class=\"nav-item\">
                        <a class=\"nav-link\" href=\"{{ url('author_index') }}\">
                            <label>VIEW Authors</label>
                        </a>
                    </li>
                    <li class=\"nav-item\">
                        <a class=\"nav-link\" href=\"{{ url('author_new') }}\">
                            <label>ADD Author</label>
                        </a>
                    </li>
        {% if is_granted('ROLE_SUPER_USER') %}
                    <li class=\"nav-item\">
                        <a class=\"nav-link\" href=\"{{ url('change_log_index') }}\">
                          <label>ChangeLog</label>
                        </a>
                    </li>
        </li>
        <li class=\"nav-item\">
            <a class=\"nav-link\" href=\"{{ url('add_user') }}\">
               <label>ADD User</label>
            </a>
        </li>
        <li class=\"nav-item\">
            <a class=\"nav-link\" href=\"{{ url('users_index') }}\">
                <label>VIEW/EDIT User</label>
            </a>
        </li>
        {% endif %}
                </ul>
                </nav>
{% endblock %}
", "include/adminpanel.html.twig", "/usr/share/nginx/html/sybook/templates/include/adminpanel.html.twig");
    }
}
