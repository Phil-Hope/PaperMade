<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* books/index.html.twig */
class __TwigTemplate_3e68b88eaf5785be40e29a19d5f6a6b9c438ea5f0d13a4e00b6acf5ccb096edf extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "books/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "books/index.html.twig"));

        // line 1
        echo "
";
        // line 2
        $this->loadTemplate("include/header.html.twig", "books/index.html.twig", 2)->display($context);
        // line 3
        echo "<style>
    th
    {
        font-size:1vw;
    }
    td
    {
        font-size: 0.8vw;
        max-width: 20vw;
    }
</style>
<div class=\"container-fluid\">
<div class=\"row\">
    <div class=\"col-1\">
";
        // line 17
        $this->loadTemplate("include/adminpanel.html.twig", "books/index.html.twig", 17)->display($context);
        // line 18
        echo "    </div>
    <div class=\"col-11\">
        <div style=\"overflow-y:scroll; height: auto;\">
            <div class=\"table-responsive\">
    <table class=\"table\">
        <thead>
            <tr>
                <th></th>
                <th>BookTitle</th>
                <th>OriginalTitle</th>
                <th>YearofPublication</th>
                <th>Genre</th>
                <th>MillionsSold</th>
                <th>LanguageWritten</th>
                <th>CoverImagePath</th>
                <th></th>
                <th>Author</th>
            </tr>
        </thead>
        <tbody>
        ";
        // line 38
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["books"]) || array_key_exists("books", $context) ? $context["books"] : (function () { throw new RuntimeError('Variable "books" does not exist.', 38, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["book"]) {
            // line 39
            echo "            <tr>
                <td>
                    <a class=\"btn btn-success\" style=\"height: 1.5vw; width: 4vw; margin-top: 0.5vw;\" href=\"";
            // line 41
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("books_show", ["id" => twig_get_attribute($this->env, $this->source, $context["book"], "id", [], "any", false, false, false, 41)]), "html", null, true);
            echo "\"><strong>SHOW</strong></a>
                    <a class=\"btn btn-warning\" style=\"height: 1.5vw; width: 4vw; margin-top: 0.5vw;\" href=\"";
            // line 42
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("books_edit", ["id" => twig_get_attribute($this->env, $this->source, $context["book"], "id", [], "any", false, false, false, 42)]), "html", null, true);
            echo "\"><strong>EDIT</strong></a>
                </td>
                <td>";
            // line 44
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["book"], "BookTitle", [], "any", false, false, false, 44), "html", null, true);
            echo "</td>
                <td>";
            // line 45
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["book"], "OriginalTitle", [], "any", false, false, false, 45), "html", null, true);
            echo "</td>
                <td>";
            // line 46
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["book"], "YearofPublication", [], "any", false, false, false, 46), "html", null, true);
            echo "</td>
                <td>";
            // line 47
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["book"], "Genre", [], "any", false, false, false, 47), "html", null, true);
            echo "</td>
                <td>";
            // line 48
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["book"], "MillionsSold", [], "any", false, false, false, 48), "html", null, true);
            echo "</td>
                <td>";
            // line 49
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["book"], "LanguageWritten", [], "any", false, false, false, 49), "html", null, true);
            echo "</td>
                <td><img class=\"img-thumbnail\" style=\"max-height: 10vw; width: auto;\" src=\"";
            // line 50
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["book"], "coverImagePath", [], "any", false, false, false, 50), "html", null, true);
            echo "\"></td>
                ";
            // line 51
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["authors"]) || array_key_exists("authors", $context) ? $context["authors"] : (function () { throw new RuntimeError('Variable "authors" does not exist.', 51, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["author"]) {
                // line 52
                echo "                ";
                if (0 === twig_compare(twig_get_attribute($this->env, $this->source, $context["book"], "author", [], "any", false, false, false, 52), twig_get_attribute($this->env, $this->source, $context["author"], "id", [], "any", false, false, false, 52))) {
                    // line 53
                    echo "                    <td>";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["author"], "Name", [], "any", false, false, false, 53), "html", null, true);
                    echo " ";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["author"], "Surname", [], "any", false, false, false, 53), "html", null, true);
                    echo "</td>
            </tr>
            ";
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['author'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['book'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 58
        echo "        </tbody>
    </table>
</div>
    </div>
    </div>
</div>
</div>
";
        // line 65
        $this->loadTemplate("include/footer.html.twig", "books/index.html.twig", 65)->display($context);
        // line 66
        echo "
";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "books/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  168 => 66,  166 => 65,  157 => 58,  140 => 53,  137 => 52,  133 => 51,  129 => 50,  125 => 49,  121 => 48,  117 => 47,  113 => 46,  109 => 45,  105 => 44,  100 => 42,  96 => 41,  92 => 39,  88 => 38,  66 => 18,  64 => 17,  48 => 3,  46 => 2,  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("
{% include 'include/header.html.twig' %}
<style>
    th
    {
        font-size:1vw;
    }
    td
    {
        font-size: 0.8vw;
        max-width: 20vw;
    }
</style>
<div class=\"container-fluid\">
<div class=\"row\">
    <div class=\"col-1\">
{% include 'include/adminpanel.html.twig' %}
    </div>
    <div class=\"col-11\">
        <div style=\"overflow-y:scroll; height: auto;\">
            <div class=\"table-responsive\">
    <table class=\"table\">
        <thead>
            <tr>
                <th></th>
                <th>BookTitle</th>
                <th>OriginalTitle</th>
                <th>YearofPublication</th>
                <th>Genre</th>
                <th>MillionsSold</th>
                <th>LanguageWritten</th>
                <th>CoverImagePath</th>
                <th></th>
                <th>Author</th>
            </tr>
        </thead>
        <tbody>
        {% for book in books %}
            <tr>
                <td>
                    <a class=\"btn btn-success\" style=\"height: 1.5vw; width: 4vw; margin-top: 0.5vw;\" href=\"{{ path('books_show', {'id': book.id}) }}\"><strong>SHOW</strong></a>
                    <a class=\"btn btn-warning\" style=\"height: 1.5vw; width: 4vw; margin-top: 0.5vw;\" href=\"{{ path('books_edit', {'id': book.id}) }}\"><strong>EDIT</strong></a>
                </td>
                <td>{{ book.BookTitle }}</td>
                <td>{{ book.OriginalTitle }}</td>
                <td>{{ book.YearofPublication }}</td>
                <td>{{ book.Genre }}</td>
                <td>{{ book.MillionsSold }}</td>
                <td>{{ book.LanguageWritten }}</td>
                <td><img class=\"img-thumbnail\" style=\"max-height: 10vw; width: auto;\" src=\"{{ book.coverImagePath }}\"></td>
                {% for author in authors %}
                {% if book.author == author.id  %}
                    <td>{{ author.Name }} {{ author.Surname }}</td>
            </tr>
            {% endif %}
{% endfor %}
{% endfor %}
        </tbody>
    </table>
</div>
    </div>
    </div>
</div>
</div>
{% include 'include/footer.html.twig' %}

", "books/index.html.twig", "/usr/share/nginx/html/sybook/templates/books/index.html.twig");
    }
}
