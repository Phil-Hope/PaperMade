<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/_profiler' => [[['_route' => '_profiler_home', '_controller' => 'web_profiler.controller.profiler::homeAction'], null, null, null, true, false, null]],
        '/_profiler/search' => [[['_route' => '_profiler_search', '_controller' => 'web_profiler.controller.profiler::searchAction'], null, null, null, false, false, null]],
        '/_profiler/search_bar' => [[['_route' => '_profiler_search_bar', '_controller' => 'web_profiler.controller.profiler::searchBarAction'], null, null, null, false, false, null]],
        '/_profiler/phpinfo' => [[['_route' => '_profiler_phpinfo', '_controller' => 'web_profiler.controller.profiler::phpinfoAction'], null, null, null, false, false, null]],
        '/_profiler/open' => [[['_route' => '_profiler_open_file', '_controller' => 'web_profiler.controller.profiler::openAction'], null, null, null, false, false, null]],
        '/admin' => [
            [['_route' => 'app_admin_index', '_controller' => 'App\\Controller\\AdminController::index'], null, null, null, true, false, null],
            [['_route' => 'admin', '_controller' => 'App\\Controller\\AdminController::index'], null, null, null, false, false, null],
        ],
        '/admin/author' => [[['_route' => 'author_index', '_controller' => 'App\\Controller\\AuthorController::index'], null, ['GET' => 0], null, true, false, null]],
        '/admin/author/new' => [[['_route' => 'author_new', '_controller' => 'App\\Controller\\AuthorController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/admin/books' => [[['_route' => 'books_index', '_controller' => 'App\\Controller\\BooksController::index'], null, ['GET' => 0], null, true, false, null]],
        '/admin/books/new' => [[['_route' => 'books_new', '_controller' => 'App\\Controller\\BooksController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/change/log' => [[['_route' => 'change_log_index', '_controller' => 'App\\Controller\\ChangeLogController::index'], null, ['GET' => 0], null, true, false, null]],
        '/change/log/new' => [[['_route' => 'change_log_new', '_controller' => 'App\\Controller\\ChangeLogController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/login' => [[['_route' => 'app_login', '_controller' => 'App\\Controller\\CheckLoginController::login'], null, null, null, false, false, null]],
        '/logout' => [[['_route' => 'app_logout', '_controller' => 'App\\Controller\\CheckLoginController::logout'], null, null, null, false, false, null]],
        '/' => [[['_route' => 'home', '_controller' => 'App\\Controller\\HomeController::index'], null, null, null, false, false, null]],
        '/admin/users' => [[['_route' => 'users_index', '_controller' => 'App\\Controller\\UsersController::index'], null, ['GET' => 0], null, true, false, null]],
        '/admin/users/add_user' => [[['_route' => 'add_user', '_controller' => 'App\\Controller\\UsersController::register'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_(?'
                    .'|error/(\\d+)(?:\\.([^/]++))?(*:38)'
                    .'|wdt/([^/]++)(*:57)'
                    .'|profiler/([^/]++)(?'
                        .'|/(?'
                            .'|search/results(*:102)'
                            .'|router(*:116)'
                            .'|exception(?'
                                .'|(*:136)'
                                .'|\\.css(*:149)'
                            .')'
                        .')'
                        .'|(*:159)'
                    .')'
                .')'
                .'|/admin/(?'
                    .'|author/([^/]++)(?'
                        .'|(*:197)'
                        .'|/edit(*:210)'
                        .'|(*:218)'
                    .')'
                    .'|books/([^/]++)(?'
                        .'|(*:244)'
                        .'|/edit(*:257)'
                        .'|(*:265)'
                    .')'
                    .'|users/([^/]++)(?'
                        .'|(*:291)'
                        .'|/edit(*:304)'
                        .'|(*:312)'
                    .')'
                .')'
                .'|/change/log/([^/]++)(?'
                    .'|(*:345)'
                    .'|/edit(*:358)'
                    .'|(*:366)'
                .')'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        38 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        57 => [[['_route' => '_wdt', '_controller' => 'web_profiler.controller.profiler::toolbarAction'], ['token'], null, null, false, true, null]],
        102 => [[['_route' => '_profiler_search_results', '_controller' => 'web_profiler.controller.profiler::searchResultsAction'], ['token'], null, null, false, false, null]],
        116 => [[['_route' => '_profiler_router', '_controller' => 'web_profiler.controller.router::panelAction'], ['token'], null, null, false, false, null]],
        136 => [[['_route' => '_profiler_exception', '_controller' => 'web_profiler.controller.exception_panel::body'], ['token'], null, null, false, false, null]],
        149 => [[['_route' => '_profiler_exception_css', '_controller' => 'web_profiler.controller.exception_panel::stylesheet'], ['token'], null, null, false, false, null]],
        159 => [[['_route' => '_profiler', '_controller' => 'web_profiler.controller.profiler::panelAction'], ['token'], null, null, false, true, null]],
        197 => [[['_route' => 'author_show', '_controller' => 'App\\Controller\\AuthorController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        210 => [[['_route' => 'author_edit', '_controller' => 'App\\Controller\\AuthorController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        218 => [[['_route' => 'author_delete', '_controller' => 'App\\Controller\\AuthorController::delete'], ['id'], ['DELETE' => 0], null, false, true, null]],
        244 => [[['_route' => 'books_show', '_controller' => 'App\\Controller\\BooksController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        257 => [[['_route' => 'books_edit', '_controller' => 'App\\Controller\\BooksController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        265 => [[['_route' => 'books_delete', '_controller' => 'App\\Controller\\BooksController::delete'], ['id'], ['DELETE' => 0], null, false, true, null]],
        291 => [[['_route' => 'users_show', '_controller' => 'App\\Controller\\UsersController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        304 => [[['_route' => 'users_edit', '_controller' => 'App\\Controller\\UsersController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        312 => [[['_route' => 'users_delete', '_controller' => 'App\\Controller\\UsersController::delete'], ['id'], ['DELETE' => 0], null, false, true, null]],
        345 => [[['_route' => 'change_log_show', '_controller' => 'App\\Controller\\ChangeLogController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        358 => [[['_route' => 'change_log_edit', '_controller' => 'App\\Controller\\ChangeLogController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        366 => [
            [['_route' => 'change_log_delete', '_controller' => 'App\\Controller\\ChangeLogController::delete'], ['id'], ['DELETE' => 0], null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
